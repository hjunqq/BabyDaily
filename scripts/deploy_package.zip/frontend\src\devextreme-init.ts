﻿import config from 'devextreme/core/config';
import { licenseKey } from './devextreme-license';

config({
  licenseKey,
});
